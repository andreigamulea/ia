--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ia_development;
--
-- Name: ia_development; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ia_development WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE ia_development OWNER TO postgres;

\connect ia_development

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO postgres;

--
-- Name: cursuri_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cursuri_history (
    id bigint NOT NULL,
    user_id bigint,
    listacursuri_id bigint NOT NULL,
    cursuri_id integer NOT NULL,
    datainceput date,
    datasfarsit date,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    email character varying,
    observatii text
);


ALTER TABLE public.cursuri_history OWNER TO postgres;

--
-- Name: cursuri_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cursuri_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cursuri_history_id_seq OWNER TO postgres;

--
-- Name: cursuri_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cursuri_history_id_seq OWNED BY public.cursuri_history.id;


--
-- Name: cursuris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cursuris (
    id bigint NOT NULL,
    datainceput date,
    datasfarsit date,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    listacursuri_id integer,
    user_id integer
);


ALTER TABLE public.cursuris OWNER TO postgres;

--
-- Name: cursuris_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cursuris_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cursuris_id_seq OWNER TO postgres;

--
-- Name: cursuris_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cursuris_id_seq OWNED BY public.cursuris.id;


--
-- Name: importanta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.importanta (
    id bigint NOT NULL,
    codimp integer,
    grad character varying,
    descgrad character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.importanta OWNER TO postgres;

--
-- Name: importanta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.importanta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.importanta_id_seq OWNER TO postgres;

--
-- Name: importanta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.importanta_id_seq OWNED BY public.importanta.id;


--
-- Name: listacursuris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listacursuris (
    id bigint NOT NULL,
    nume character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.listacursuris OWNER TO postgres;

--
-- Name: listacursuris_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listacursuris_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.listacursuris_id_seq OWNER TO postgres;

--
-- Name: listacursuris_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listacursuris_id_seq OWNED BY public.listacursuris.id;


--
-- Name: listaproprietatis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.listaproprietatis (
    id bigint NOT NULL,
    idx integer,
    proprietateter character varying,
    tipp character varying,
    srota integer,
    definire text,
    sinonime text,
    selectie character varying,
    sel integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.listaproprietatis OWNER TO postgres;

--
-- Name: listaproprietatis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.listaproprietatis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.listaproprietatis_id_seq OWNER TO postgres;

--
-- Name: listaproprietatis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.listaproprietatis_id_seq OWNED BY public.listaproprietatis.id;


--
-- Name: paginisites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.paginisites (
    id bigint NOT NULL,
    nume character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.paginisites OWNER TO postgres;

--
-- Name: paginisites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.paginisites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.paginisites_id_seq OWNER TO postgres;

--
-- Name: paginisites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.paginisites_id_seq OWNED BY public.paginisites.id;


--
-- Name: plante_partis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plante_partis (
    id bigint NOT NULL,
    idx integer,
    cpl integer,
    parte character varying,
    part character varying,
    clasa character varying,
    invpp character varying,
    tippp character varying,
    recomandari character varying,
    textsursa character varying,
    starereprez character varying,
    z character varying,
    healthrel character varying,
    compozitie character varying,
    etich character varying,
    healthrelrom character varying,
    propspeciale character varying,
    selectie character varying,
    lucru character varying,
    s character varying,
    sel character varying,
    index2 integer,
    ordvol character varying,
    selpz character varying,
    selpzn character varying,
    sels character varying,
    selz character varying,
    selnr character varying,
    t10 character varying,
    t11 character varying,
    t12 character varying,
    t13 character varying,
    t14 character varying,
    t15 character varying,
    t16 character varying,
    b character varying,
    r character varying,
    c character varying,
    imp character varying,
    testat character varying,
    g1 character varying,
    g2 character varying,
    g3 character varying,
    g4 character varying,
    g5 character varying,
    g6 character varying,
    vir character varying,
    vip character varying,
    imaginepp character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.plante_partis OWNER TO postgres;

--
-- Name: plante_partis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plante_partis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plante_partis_id_seq OWNER TO postgres;

--
-- Name: plante_partis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plante_partis_id_seq OWNED BY public.plante_partis.id;


--
-- Name: plantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plantes (
    id bigint NOT NULL,
    idp integer,
    tip character varying,
    subt character varying,
    nume character varying,
    denbot character varying,
    numesec character varying,
    numesec2 character varying,
    numeayu character varying,
    fam character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.plantes OWNER TO postgres;

--
-- Name: plantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plantes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plantes_id_seq OWNER TO postgres;

--
-- Name: plantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plantes_id_seq OWNED BY public.plantes.id;


--
-- Name: recomandaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recomandaris (
    id bigint NOT NULL,
    listaproprietati_id integer,
    idpr integer,
    idp integer,
    idpp integer,
    imp character varying,
    tipp character varying,
    srota integer,
    proprietate character varying,
    propeng character varying,
    propayur character varying,
    propgerm character varying,
    completari character varying,
    sursa character varying,
    sel character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.recomandaris OWNER TO postgres;

--
-- Name: recomandaris_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recomandaris_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recomandaris_id_seq OWNER TO postgres;

--
-- Name: recomandaris_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recomandaris_id_seq OWNED BY public.recomandaris.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: srota; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.srota (
    id bigint NOT NULL,
    codsrota integer,
    codsr integer,
    numesrota character varying,
    numescurt character varying,
    explicatie character varying,
    origine character varying,
    parti character varying,
    functii character varying,
    observatie character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.srota OWNER TO postgres;

--
-- Name: srota_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.srota_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.srota_id_seq OWNER TO postgres;

--
-- Name: srota_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.srota_id_seq OWNED BY public.srota.id;


--
-- Name: tipuri_props; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipuri_props (
    id bigint NOT NULL,
    idxcp integer,
    cp character varying,
    explicatie character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.tipuri_props OWNER TO postgres;

--
-- Name: tipuri_props_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipuri_props_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tipuri_props_id_seq OWNER TO postgres;

--
-- Name: tipuri_props_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipuri_props_id_seq OWNED BY public.tipuri_props.id;


--
-- Name: user_paginisites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_paginisites (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    paginisite_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.user_paginisites OWNER TO postgres;

--
-- Name: user_paginisites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_paginisites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_paginisites_id_seq OWNER TO postgres;

--
-- Name: user_paginisites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_paginisites_id_seq OWNED BY public.user_paginisites.id;


--
-- Name: user_unhappies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_unhappies (
    id bigint NOT NULL,
    user_id integer,
    name character varying,
    email character varying,
    role integer,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.user_unhappies OWNER TO postgres;

--
-- Name: user_unhappies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_unhappies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_unhappies_id_seq OWNER TO postgres;

--
-- Name: user_unhappies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_unhappies_id_seq OWNED BY public.user_unhappies.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    name character varying,
    role integer,
    reset_password_token character varying,
    reset_password_sent_at timestamp(6) without time zone,
    remember_created_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    active boolean
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: valorinutritionales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.valorinutritionales (
    id bigint NOT NULL,
    cod integer,
    aliment character varying,
    calorii double precision,
    proteine double precision,
    lipide double precision,
    carbohidrati double precision,
    fibre double precision,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    observatii text
);


ALTER TABLE public.valorinutritionales OWNER TO postgres;

--
-- Name: valorinutritionales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.valorinutritionales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.valorinutritionales_id_seq OWNER TO postgres;

--
-- Name: valorinutritionales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.valorinutritionales_id_seq OWNED BY public.valorinutritionales.id;


--
-- Name: cursuri_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursuri_history ALTER COLUMN id SET DEFAULT nextval('public.cursuri_history_id_seq'::regclass);


--
-- Name: cursuris id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursuris ALTER COLUMN id SET DEFAULT nextval('public.cursuris_id_seq'::regclass);


--
-- Name: importanta id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.importanta ALTER COLUMN id SET DEFAULT nextval('public.importanta_id_seq'::regclass);


--
-- Name: listacursuris id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listacursuris ALTER COLUMN id SET DEFAULT nextval('public.listacursuris_id_seq'::regclass);


--
-- Name: listaproprietatis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listaproprietatis ALTER COLUMN id SET DEFAULT nextval('public.listaproprietatis_id_seq'::regclass);


--
-- Name: paginisites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paginisites ALTER COLUMN id SET DEFAULT nextval('public.paginisites_id_seq'::regclass);


--
-- Name: plante_partis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plante_partis ALTER COLUMN id SET DEFAULT nextval('public.plante_partis_id_seq'::regclass);


--
-- Name: plantes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantes ALTER COLUMN id SET DEFAULT nextval('public.plantes_id_seq'::regclass);


--
-- Name: recomandaris id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recomandaris ALTER COLUMN id SET DEFAULT nextval('public.recomandaris_id_seq'::regclass);


--
-- Name: srota id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.srota ALTER COLUMN id SET DEFAULT nextval('public.srota_id_seq'::regclass);


--
-- Name: tipuri_props id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipuri_props ALTER COLUMN id SET DEFAULT nextval('public.tipuri_props_id_seq'::regclass);


--
-- Name: user_paginisites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_paginisites ALTER COLUMN id SET DEFAULT nextval('public.user_paginisites_id_seq'::regclass);


--
-- Name: user_unhappies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_unhappies ALTER COLUMN id SET DEFAULT nextval('public.user_unhappies_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: valorinutritionales id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.valorinutritionales ALTER COLUMN id SET DEFAULT nextval('public.valorinutritionales_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
\.
COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM '$$PATH$$/3467.dat';

--
-- Data for Name: cursuri_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cursuri_history (id, user_id, listacursuri_id, cursuri_id, datainceput, datasfarsit, created_at, updated_at, email, observatii) FROM stdin;
\.
COPY public.cursuri_history (id, user_id, listacursuri_id, cursuri_id, datainceput, datasfarsit, created_at, updated_at, email, observatii) FROM '$$PATH$$/3491.dat';

--
-- Data for Name: cursuris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cursuris (id, datainceput, datasfarsit, created_at, updated_at, listacursuri_id, user_id) FROM stdin;
\.
COPY public.cursuris (id, datainceput, datasfarsit, created_at, updated_at, listacursuri_id, user_id) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: importanta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.importanta (id, codimp, grad, descgrad, created_at, updated_at) FROM stdin;
\.
COPY public.importanta (id, codimp, grad, descgrad, created_at, updated_at) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: listacursuris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listacursuris (id, nume, created_at, updated_at) FROM stdin;
\.
COPY public.listacursuris (id, nume, created_at, updated_at) FROM '$$PATH$$/3489.dat';

--
-- Data for Name: listaproprietatis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.listaproprietatis (id, idx, proprietateter, tipp, srota, definire, sinonime, selectie, sel, created_at, updated_at) FROM stdin;
\.
COPY public.listaproprietatis (id, idx, proprietateter, tipp, srota, definire, sinonime, selectie, sel, created_at, updated_at) FROM '$$PATH$$/3477.dat';

--
-- Data for Name: paginisites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.paginisites (id, nume, created_at, updated_at) FROM stdin;
\.
COPY public.paginisites (id, nume, created_at, updated_at) FROM '$$PATH$$/3495.dat';

--
-- Data for Name: plante_partis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plante_partis (id, idx, cpl, parte, part, clasa, invpp, tippp, recomandari, textsursa, starereprez, z, healthrel, compozitie, etich, healthrelrom, propspeciale, selectie, lucru, s, sel, index2, ordvol, selpz, selpzn, sels, selz, selnr, t10, t11, t12, t13, t14, t15, t16, b, r, c, imp, testat, g1, g2, g3, g4, g5, g6, vir, vip, imaginepp, created_at, updated_at) FROM stdin;
\.
COPY public.plante_partis (id, idx, cpl, parte, part, clasa, invpp, tippp, recomandari, textsursa, starereprez, z, healthrel, compozitie, etich, healthrelrom, propspeciale, selectie, lucru, s, sel, index2, ordvol, selpz, selpzn, sels, selz, selnr, t10, t11, t12, t13, t14, t15, t16, b, r, c, imp, testat, g1, g2, g3, g4, g5, g6, vir, vip, imaginepp, created_at, updated_at) FROM '$$PATH$$/3473.dat';

--
-- Data for Name: plantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plantes (id, idp, tip, subt, nume, denbot, numesec, numesec2, numeayu, fam, created_at, updated_at) FROM stdin;
\.
COPY public.plantes (id, idp, tip, subt, nume, denbot, numesec, numesec2, numeayu, fam, created_at, updated_at) FROM '$$PATH$$/3471.dat';

--
-- Data for Name: recomandaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recomandaris (id, listaproprietati_id, idpr, idp, idpp, imp, tipp, srota, proprietate, propeng, propayur, propgerm, completari, sursa, sel, created_at, updated_at) FROM stdin;
\.
COPY public.recomandaris (id, listaproprietati_id, idpr, idp, idpp, imp, tipp, srota, proprietate, propeng, propayur, propgerm, completari, sursa, sel, created_at, updated_at) FROM '$$PATH$$/3475.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version) FROM stdin;
\.
COPY public.schema_migrations (version) FROM '$$PATH$$/3466.dat';

--
-- Data for Name: srota; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.srota (id, codsrota, codsr, numesrota, numescurt, explicatie, origine, parti, functii, observatie, created_at, updated_at) FROM stdin;
\.
COPY public.srota (id, codsrota, codsr, numesrota, numescurt, explicatie, origine, parti, functii, observatie, created_at, updated_at) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: tipuri_props; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipuri_props (id, idxcp, cp, explicatie, created_at, updated_at) FROM stdin;
\.
COPY public.tipuri_props (id, idxcp, cp, explicatie, created_at, updated_at) FROM '$$PATH$$/3481.dat';

--
-- Data for Name: user_paginisites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_paginisites (id, user_id, paginisite_id, created_at, updated_at) FROM stdin;
\.
COPY public.user_paginisites (id, user_id, paginisite_id, created_at, updated_at) FROM '$$PATH$$/3497.dat';

--
-- Data for Name: user_unhappies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_unhappies (id, user_id, name, email, role, created_at, updated_at) FROM stdin;
\.
COPY public.user_unhappies (id, user_id, name, email, role, created_at, updated_at) FROM '$$PATH$$/3493.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, encrypted_password, name, role, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, active) FROM stdin;
\.
COPY public.users (id, email, encrypted_password, name, role, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at, active) FROM '$$PATH$$/3469.dat';

--
-- Data for Name: valorinutritionales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.valorinutritionales (id, cod, aliment, calorii, proteine, lipide, carbohidrati, fibre, created_at, updated_at, observatii) FROM stdin;
\.
COPY public.valorinutritionales (id, cod, aliment, calorii, proteine, lipide, carbohidrati, fibre, created_at, updated_at, observatii) FROM '$$PATH$$/3485.dat';

--
-- Name: cursuri_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cursuri_history_id_seq', 820, true);


--
-- Name: cursuris_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cursuris_id_seq', 1859, true);


--
-- Name: importanta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.importanta_id_seq', 3, true);


--
-- Name: listacursuris_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listacursuris_id_seq', 5, true);


--
-- Name: listaproprietatis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.listaproprietatis_id_seq', 867, true);


--
-- Name: paginisites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.paginisites_id_seq', 2, true);


--
-- Name: plante_partis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plante_partis_id_seq', 536, true);


--
-- Name: plantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plantes_id_seq', 431, true);


--
-- Name: recomandaris_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recomandaris_id_seq', 19569, true);


--
-- Name: srota_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.srota_id_seq', 15, true);


--
-- Name: tipuri_props_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipuri_props_id_seq', 6, true);


--
-- Name: user_paginisites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_paginisites_id_seq', 11, true);


--
-- Name: user_unhappies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_unhappies_id_seq', 10, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1570, true);


--
-- Name: valorinutritionales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.valorinutritionales_id_seq', 4246, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: cursuri_history cursuri_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursuri_history
    ADD CONSTRAINT cursuri_history_pkey PRIMARY KEY (id);


--
-- Name: cursuris cursuris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursuris
    ADD CONSTRAINT cursuris_pkey PRIMARY KEY (id);


--
-- Name: importanta importanta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.importanta
    ADD CONSTRAINT importanta_pkey PRIMARY KEY (id);


--
-- Name: listacursuris listacursuris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listacursuris
    ADD CONSTRAINT listacursuris_pkey PRIMARY KEY (id);


--
-- Name: listaproprietatis listaproprietatis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.listaproprietatis
    ADD CONSTRAINT listaproprietatis_pkey PRIMARY KEY (id);


--
-- Name: paginisites paginisites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.paginisites
    ADD CONSTRAINT paginisites_pkey PRIMARY KEY (id);


--
-- Name: plante_partis plante_partis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plante_partis
    ADD CONSTRAINT plante_partis_pkey PRIMARY KEY (id);


--
-- Name: plantes plantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantes
    ADD CONSTRAINT plantes_pkey PRIMARY KEY (id);


--
-- Name: recomandaris recomandaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recomandaris
    ADD CONSTRAINT recomandaris_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: srota srota_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.srota
    ADD CONSTRAINT srota_pkey PRIMARY KEY (id);


--
-- Name: tipuri_props tipuri_props_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipuri_props
    ADD CONSTRAINT tipuri_props_pkey PRIMARY KEY (id);


--
-- Name: user_paginisites user_paginisites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_paginisites
    ADD CONSTRAINT user_paginisites_pkey PRIMARY KEY (id);


--
-- Name: user_unhappies user_unhappies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_unhappies
    ADD CONSTRAINT user_unhappies_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: valorinutritionales valorinutritionales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.valorinutritionales
    ADD CONSTRAINT valorinutritionales_pkey PRIMARY KEY (id);


--
-- Name: index_cursuri_history_on_listacursuri_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_cursuri_history_on_listacursuri_id ON public.cursuri_history USING btree (listacursuri_id);


--
-- Name: index_cursuri_history_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_cursuri_history_on_user_id ON public.cursuri_history USING btree (user_id);


--
-- Name: index_cursuris_on_listacursuri_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_cursuris_on_listacursuri_id ON public.cursuris USING btree (listacursuri_id);


--
-- Name: index_cursuris_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_cursuris_on_user_id ON public.cursuris USING btree (user_id);


--
-- Name: index_listaproprietatis_on_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_listaproprietatis_on_idx ON public.listaproprietatis USING btree (idx);


--
-- Name: index_listaproprietatis_on_proprietateter; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_listaproprietatis_on_proprietateter ON public.listaproprietatis USING btree (proprietateter);


--
-- Name: index_listaproprietatis_on_srota; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_listaproprietatis_on_srota ON public.listaproprietatis USING btree (srota);


--
-- Name: index_plante_partis_on_cpl; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_plante_partis_on_cpl ON public.plante_partis USING btree (cpl);


--
-- Name: index_plante_partis_on_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_plante_partis_on_idx ON public.plante_partis USING btree (idx);


--
-- Name: index_plante_partis_on_index2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_plante_partis_on_index2 ON public.plante_partis USING btree (index2);


--
-- Name: index_plantes_on_idp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_plantes_on_idp ON public.plantes USING btree (idp);


--
-- Name: index_plantes_on_nume; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_plantes_on_nume ON public.plantes USING btree (nume);


--
-- Name: index_recomandaris_on_idpp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_recomandaris_on_idpp ON public.recomandaris USING btree (idpp);


--
-- Name: index_recomandaris_on_listaproprietati_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_recomandaris_on_listaproprietati_id ON public.recomandaris USING btree (listaproprietati_id);


--
-- Name: index_recomandaris_on_srota; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_recomandaris_on_srota ON public.recomandaris USING btree (srota);


--
-- Name: index_srota_on_codsr; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_srota_on_codsr ON public.srota USING btree (codsr);


--
-- Name: index_srota_on_codsrota; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_srota_on_codsrota ON public.srota USING btree (codsrota);


--
-- Name: index_user_paginisites_on_paginisite_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_paginisites_on_paginisite_id ON public.user_paginisites USING btree (paginisite_id);


--
-- Name: index_user_paginisites_on_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_paginisites_on_user_id ON public.user_paginisites USING btree (user_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_name ON public.users USING btree (name);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_users_on_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_users_on_role ON public.users USING btree (role);


--
-- Name: index_valorinutritionales_on_aliment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_valorinutritionales_on_aliment ON public.valorinutritionales USING btree (aliment);


--
-- Name: index_valorinutritionales_on_calorii; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_valorinutritionales_on_calorii ON public.valorinutritionales USING btree (calorii);


--
-- Name: index_valorinutritionales_on_carbohidrati; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_valorinutritionales_on_carbohidrati ON public.valorinutritionales USING btree (carbohidrati);


--
-- Name: index_valorinutritionales_on_cod; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_valorinutritionales_on_cod ON public.valorinutritionales USING btree (cod);


--
-- Name: index_valorinutritionales_on_fibre; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_valorinutritionales_on_fibre ON public.valorinutritionales USING btree (fibre);


--
-- Name: index_valorinutritionales_on_lipide; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_valorinutritionales_on_lipide ON public.valorinutritionales USING btree (lipide);


--
-- Name: index_valorinutritionales_on_proteine; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_valorinutritionales_on_proteine ON public.valorinutritionales USING btree (proteine);


--
-- Name: user_paginisites fk_rails_2e778bbe7b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_paginisites
    ADD CONSTRAINT fk_rails_2e778bbe7b FOREIGN KEY (paginisite_id) REFERENCES public.paginisites(id);


--
-- Name: cursuri_history fk_rails_5a460f5c28; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursuri_history
    ADD CONSTRAINT fk_rails_5a460f5c28 FOREIGN KEY (listacursuri_id) REFERENCES public.listacursuris(id);


--
-- Name: cursuri_history fk_rails_6469f0a042; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursuri_history
    ADD CONSTRAINT fk_rails_6469f0a042 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: user_paginisites fk_rails_deb258b0f6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_paginisites
    ADD CONSTRAINT fk_rails_deb258b0f6 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

